docker run -d pacs3436/test_mnist:0.0.2
