./run_in_docker.sh python mnist_tensorflow_light.py /tmp/mnist
