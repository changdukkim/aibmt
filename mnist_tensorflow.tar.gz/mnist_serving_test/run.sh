./run_in_docker.sh python mnist_client.py   --num_tests=1000 --server=127.0.0.1:8500
